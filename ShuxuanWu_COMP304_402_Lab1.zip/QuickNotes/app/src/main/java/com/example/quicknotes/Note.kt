package com.example.quicknotes

data class Note(
    val id: Int,
    var title: String,
    var content: String
)

